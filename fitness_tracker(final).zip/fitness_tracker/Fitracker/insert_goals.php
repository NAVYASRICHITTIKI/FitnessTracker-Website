<?php
header("Access-Control-Allow-Origin: http://localhost:3000"); // React App URL
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$servername = "localhost:3307"; // MySQL server running on port 3307
$username = "root"; // MySQL username
$password = " "; // MySQL password
$dbname = "bhanu"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get goal data from the POST request
$data = json_decode(file_get_contents("php://input"));
$user_id = $data->user_id;
$selectedGoals = $data->selectedGoals; // Array of goal ids

$errors = []; // To collect errors

// Insert user goals into USER_GOALS_TABLE
foreach ($selectedGoals as $goal) {
    // Insert selected goal into USER_GOALS_TABLE
    $goal_id = $goal->goal_id;
    $target_value = $goal->target_value;

    // Using prepared statements for security
    $stmt = $conn->prepare("INSERT INTO USER_GOALS_TABLE (user_id, goal_id, target_value) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $user_id, $goal_id, $target_value);

    if (!$stmt->execute()) {
        $errors[] = "Failed to insert goal ID: $goal_id, Target Value: $target_value";
    }

    $stmt->close();
}

if (empty($errors)) {
    echo json_encode(["success" => true, "message" => "Goals saved successfully"]);
} else {
    echo json_encode(["success" => false, "error" => $errors]);
}

$conn->close();
?>
